# DigitalBank App

Created by:
Jonathan Erwin Tuazon
July: 07/08/2021

Created for the purpose of assement.

Procedures:

Read and Analyze Documentation.

Connect to sandbox to get the access token for authetication.

Register or Login to Selected bank to get Access code and Connection ID for the requirements of exchane token.

Execute Exchange token to acquired Access token and User Secret.

Use Access token and User Secret to get Bank Details.

Create Beneficiaries to initiate transfer.

Once Beneficiary is created, you can now Transfer Amount and view transaction history.


