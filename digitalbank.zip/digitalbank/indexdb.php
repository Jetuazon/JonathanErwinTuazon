



curl --request POST 
  --url https://api.dapi.co/v2/apps/sandbox/CreateUser
  --header 'Content-Type: application/json' 

{
    "appKey": "jcZzoZI64EohkNGXrbxR",
    "username": "johndoe1",
    "password": "password1",
    "bankID": "DAPIBANK_AE_ADIB"
}
